# Blacklist3r

The goal of this project is to accumulate the secret keys / secret materials related to various web frameworks, that are publicly available and potentially used by developers. These secrets will be utilized by the Blacklist3r tools to audit the target application and verify the usage of these pre-published keys. 

We are releasing this project with.Net machine key tool to identify usage of pre-shared Machine Keys in the application for encryption and decryption of forms authentication cookie.

Detailed Description: https://www.notsosecure.com/project-blacklist3r/
